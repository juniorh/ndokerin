﻿

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Kompozycja";

thePlugins.get("theme").langLoaded();
