﻿

 theUILang.themeStandard	= "Tiêu chuẩn";
 theUILang.theme		= "Chủ đề";

thePlugins.get("theme").langLoaded();