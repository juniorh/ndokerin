﻿

 theUILang.themeStandard	= "Стандартна";
 theUILang.theme		= "Палітра";

thePlugins.get("theme").langLoaded();