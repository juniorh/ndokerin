<?php

$showItemDescription = true;

?>