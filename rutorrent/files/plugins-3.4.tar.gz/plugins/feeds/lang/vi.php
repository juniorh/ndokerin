<?php

$theUILang["all"]		= "Tất cả Torrent";
$theUILang["completed"] 	= "Torrent đã hoàn thành";
$theUILang["downloading"]	= "Torrent đang tải";
$theUILang["active"]		= "Torrent đang hoạt động";
$theUILang["inactive"]		= "Torrent không hoạt động";
$theUILang["error"]		= "Torrent lỗi";
$theUILang["Transfer"]		= "Truyền tải";
$theUILang["Size"]		= "Kích thước";
$theUILang["Remaining"] 	= "Còn lại";
$theUILang["Share_ratio"]	= "Tỉ lệ chia sẻ";
$theUILang["Downloaded"]	= "Đã tải xuống"; 
$theUILang["Down_speed"]	= "Tốc độ tải xuống";
$theUILang["Uploaded"]		= "Đã tải lên";
$theUILang["Ul_speed"]		= "Tốc độ tải lên";
$theUILang["Seeds"]		= "Máy nguồn";
$theUILang["Peers"]		= "Thành viên";
$theUILang["Track_status"]	= "Trạng thái máy theo dõi";
$theUILang["Comment"]		= "Ghi chú";
$theUILang["s"] 		= "s";
$theUILang["bytes"]		= "bytes";
$theUILang["KB"]		= "KB";
$theUILang["MB"]		= "MB";
$theUILang["GB"]		= "GB";
$theUILang["TB"]		= "TB";
$theUILang["PB"]		= "PB";
$theUILang["time_w"]		= "tu ";
$theUILang["time_d"]		= "ng ";
$theUILang["time_h"]		= "g ";
$theUILang["time_m"]		= "ph ";
$theUILang["time_s"]		= "s ";

?>