<?php

$theUILang["all"]		= "Усі завантаження";
$theUILang["completed"] 	= "Завершені завантаження";
$theUILang["downloading"]	= "Незавершені завантаження";
$theUILang["active"]		= "Активні завантаження";
$theUILang["inactive"]		= "Неактивні завантаження";
$theUILang["error"]		= "Завантаження з помилками";
$theUILang["Transfer"]		= "Передавання";
$theUILang["Size"]		= "Розмір";
$theUILang["Remaining"] 	= "Залишилося";
$theUILang["Share_ratio"]	= "Коефіцієнт";
$theUILang["Downloaded"]	= "Завантажено"; 
$theUILang["Down_speed"]	= "Швидкість завантаження";
$theUILang["Uploaded"]		= "Роздано";
$theUILang["Ul_speed"]		= "Швидкість роздачі";
$theUILang["Seeds"]		= "Сіди";
$theUILang["Peers"]		= "Піри";
$theUILang["Track_status"]	= "Статус трекера";
$theUILang["Comment"]		= "Коментар";
$theUILang["s"] 		= "с";
$theUILang["bytes"]		= "байт";
$theUILang["KB"]		= "кб";
$theUILang["MB"]		= "Мб";
$theUILang["GB"]		= "Гб";
$theUILang["TB"]		= "Тб";
$theUILang["PB"]		= "Пб";
$theUILang["time_w"]		= "т ";
$theUILang["time_d"]		= "д ";
$theUILang["time_h"]		= "г ";
$theUILang["time_m"]		= "хв ";
$theUILang["time_s"]		= "с ";

?>
