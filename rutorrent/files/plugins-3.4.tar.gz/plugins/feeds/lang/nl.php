<?php

$theUILang["all"]		= "Alle Torrents";
$theUILang["completed"] 	= "Voltooide Torrents";
$theUILang["downloading"]	= "Torrents aan het Downloaden";
$theUILang["active"]		= "Actieve Torrents";
$theUILang["inactive"]		= "Inactieve Torrents";
$theUILang["error"]		= "Foutieve Torrents";
$theUILang["Transfer"]		= "Dataverkeer";
$theUILang["Size"]		= "Grootte";
$theUILang["Remaining"] 	= "Resterend";
$theUILang["Share_ratio"]	= "Verhouding";
$theUILang["Downloaded"]	= "Gedownload"; 
$theUILang["Down_speed"]	= "Download snelheid";
$theUILang["Uploaded"]		= "Geupload";
$theUILang["Ul_speed"]		= "Upload snelheid";
$theUILang["Seeds"]		= "Seeds";
$theUILang["Peers"]		= "Peers";
$theUILang["Track_status"]	= "Tracker Status";
$theUILang["Comment"]		= "Aantekening";
$theUILang["s"] 		= "s";
$theUILang["bytes"]		= "bytes";
$theUILang["KB"]		= "KB";
$theUILang["MB"]		= "MB";
$theUILang["GB"]		= "GB";
$theUILang["TB"]		= "TB";
$theUILang["PB"]		= "PB";
$theUILang["time_w"]		= "W ";
$theUILang["time_d"]		= "D ";
$theUILang["time_h"]		= "U ";
$theUILang["time_m"]		= "M ";
$theUILang["time_s"]		= "S ";

?>