﻿

 theUILang.cookiesDesc = "Cookies (Formaat: site|cookie1;cookie2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();