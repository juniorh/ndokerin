﻿

 theUILang.cookiesDesc = "Колачићи (Формат: host|cookie1;cookie2...)";
 theUILang.cookiesName = "Колачићи";

thePlugins.get("cookies").langLoaded();