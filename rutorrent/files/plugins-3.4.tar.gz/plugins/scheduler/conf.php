<?php
	// configuration parameters

	@define('SCH_DEF_UL', 100*1024);	// default UL (KB/s)
	@define('SCH_DEF_DL', 100*1024);	// default DL (KB/s)

	$updateInterval = 60;	// in minutes, 1-6,10,12,15,20,30 or 60

?>