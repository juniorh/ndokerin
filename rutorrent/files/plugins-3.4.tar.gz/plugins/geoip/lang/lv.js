﻿
// Contributed by art.spb, December 2009.

theUILang.countryName = "Valsts";

theUILang.country = new Array();

theUILang.country[ "ad" ] = "Andora";
theUILang.country[ "ae" ] = "Apvienotie Arābu Emirāti";
theUILang.country[ "af" ] = "Afganistānā";
theUILang.country[ "ag" ] = "Antigva un Barbuda";
theUILang.country[ "ai" ] = "Angilja";
theUILang.country[ "al" ] = "Albānija";
theUILang.country[ "am" ] = "Armēnija";
theUILang.country[ "an" ] = "Nīderlandes Antiļu salas";
theUILang.country[ "ao" ] = "Angola";
theUILang.country[ "aq" ] = "Antarktīda";
theUILang.country[ "ar" ] = "Argentīna";
theUILang.country[ "as" ] = "American Samoa";
theUILang.country[ "at" ] = "Austrija";
theUILang.country[ "au" ] = "Austrālija";
theUILang.country[ "aw" ] = "Aruba";
theUILang.country[ "ax" ] = "Ālandu salas";
theUILang.country[ "az" ] = "Azerbaidžāna";

theUILang.country[ "ba" ] = "Bosnija un Hercegovina";
theUILang.country[ "bb" ] = "Barbadosa";
theUILang.country[ "bd" ] = "Bangladesh";
theUILang.country[ "be" ] = "Beļģija";
theUILang.country[ "bf" ] = "Burkina Faso";
theUILang.country[ "bg" ] = "Bulgārija";
theUILang.country[ "bh" ] = "Bahreina";
theUILang.country[ "bi" ] = "Burundi";
theUILang.country[ "bj" ] = "Benina";
theUILang.country[ "bm" ] = "Bermuda";
theUILang.country[ "bn" ] = "Bruneja";
theUILang.country[ "bo" ] = "Bolīvija";
theUILang.country[ "br" ] = "Brazīlija";
theUILang.country[ "bs" ] = "Bahamas";
theUILang.country[ "bt" ] = "Butāna";
theUILang.country[ "bv" ] = "Buvē sala";
theUILang.country[ "bw" ] = "Botsvāna";
theUILang.country[ "by" ] = "Belarus";
theUILang.country[ "bz" ] = "Beliza";

theUILang.country[ "ca" ] = "Kanāda";
theUILang.country[ "cc" ] = "Kokosu salas";
theUILang.country[ "cd" ] = "Kongo-Kinshasa";
theUILang.country[ "cf" ] = "Centrālāfrikas Republikā";
theUILang.country[ "cg" ] = "Kongo-Brazzaville";
theUILang.country[ "ch" ] = "Šveice";
theUILang.country[ "ci" ] = "Kotdivuāra";
theUILang.country[ "ck" ] = "Kuka salas";
theUILang.country[ "cl" ] = "Čīle";
theUILang.country[ "cm" ] = "Kamerūna";
theUILang.country[ "cn" ] = "Ķīna";
theUILang.country[ "co" ] = "Kolumbija";
theUILang.country[ "cr" ] = "Kostarika";
theUILang.country[ "cu" ] = "Kuba";
theUILang.country[ "cv" ] = "Kaboverde";
theUILang.country[ "cx" ] = "Ziemassvētku Island";
theUILang.country[ "cy" ] = "Kipra";
theUILang.country[ "cz" ] = "Čehijas Republika";

theUILang.country[ "de" ] = "Vācija";
theUILang.country[ "dj" ] = "Džibutija";
theUILang.country[ "dk" ] = "Dānija";
theUILang.country[ "dm" ] = "Dominikas";
theUILang.country[ "do" ] = "Dominikānas Republikā";
theUILang.country[ "dz" ] = "Alžīrija";

theUILang.country[ "ec" ] = "Ekvadoru";
theUILang.country[ "ee" ] = "Igaunija";
theUILang.country[ "eg" ] = "Ēģipti";
theUILang.country[ "eh" ] = "Western Sahara";
theUILang.country[ "er" ] = "Eritreja";
theUILang.country[ "es" ] = "Spānija";
theUILang.country[ "et" ] = "Etiopija";
theUILang.country[ "eu" ] = "Eiropas Savienība";

theUILang.country[ "fi" ] = "Somija";
theUILang.country[ "fj" ] = "Fidži";
theUILang.country[ "fk" ] = "Folklenda salas";
theUILang.country[ "fm" ] = "Mikronēzija";
theUILang.country[ "fo" ] = "Farēru salas";
theUILang.country[ "fr" ] = "FRANCIJA";

theUILang.country[ "ga" ] = "Gabona";
theUILang.country[ "gb" ] = "Apvienotā Karaliste";
theUILang.country[ "gd" ] = "Grenada";
theUILang.country[ "ge" ] = "Gruzija";
theUILang.country[ "gf" ] = "Franču Gviāna";
theUILang.country[ "gg" ] = "Gērnsija";
theUILang.country[ "gh" ] = "Gana";
theUILang.country[ "gi" ] = "Gibraltar";
theUILang.country[ "gl" ] = "Grenlande";
theUILang.country[ "gm" ] = "Gambija";
theUILang.country[ "gn" ] = "Gvineja";
theUILang.country[ "gp" ] = "Gvadelupa";
theUILang.country[ "gq" ] = "Ekvatoriālā Gvineja";
theUILang.country[ "gr" ] = "Grieķija";
theUILang.country[ "gs" ] = "Dienviddžordžija un Dienvidsendviču salas";
theUILang.country[ "gt" ] = "Gvatemalā";
theUILang.country[ "gu" ] = "Guam";
theUILang.country[ "gw" ] = "Guinea-Bissau";
theUILang.country[ "gy" ] = "Gajāna";

theUILang.country[ "hk" ] = "Honkongas";
theUILang.country[ "hm" ] = "Hērda sala un Makdonalda salas";
theUILang.country[ "hn" ] = "Hondurasa";
theUILang.country[ "hr" ] = "Horvātija";
theUILang.country[ "ht" ] = "Haiti";
theUILang.country[ "hu" ] = "Ungārija";

theUILang.country[ "id" ] = "Indonēzija";
theUILang.country[ "ie" ] = "Īrija";
theUILang.country[ "il" ] = "Izraēla" 
theUILang.country[ "im" ] = "Isle of Man";
theUILang.country[ "in" ] = "Indija";
theUILang.country[ "io" ] = "Britu Indijas okeāna teritorija";
theUILang.country[ "iq" ] = "Irāka";
theUILang.country[ "ir" ] = "Irāna";
theUILang.country[ "is" ] = "Islande";
theUILang.country[ "it" ] = "Itālija";

theUILang.country[ "je" ] = "Krekls";
theUILang.country[ "jm" ] = "Jamaica";
theUILang.country[ "jo" ] = "Jordan";
theUILang.country[ "jp" ] = "Japan";

theUILang.country[ "ke" ] = "Kenija";
theUILang.country[ "kg" ] = "Kirgīzija";
theUILang.country[ "kh" ] = "Kambodža";
theUILang.country[ "ki" ] = "Kiribati";
theUILang.country[ "km" ] = "Komoru salas";
theUILang.country[ "kn" ] = "Sentkitsa un Nevisa";
theUILang.country[ "kp" ] = "Ziemeļkoreja";
theUILang.country[ "kr" ] = "Dienvidkoreja";
theUILang.country[ "kw" ] = "Kuveita";
theUILang.country[ "ky" ] = "Cayman Islands";
theUILang.country[ "kz" ] = "Kazahstāna";

theUILang.country[ "la" ] = "Laosa";
theUILang.country[ "lb" ] = "Libāna";
theUILang.country[ "lc" ] = "Saint Lucia";
theUILang.country[ "li" ] = "Lihtenšteina";
theUILang.country[ "lk" ] = "Šrilanka";
theUILang.country[ "lr" ] = "Libērija";
theUILang.country[ "ls" ] = "Lesoto";
theUILang.country[ "lt" ] = "Lietuva";
theUILang.country[ "lu" ] = "Luksemburga";
theUILang.country[ "lv" ] = "Latvija";
theUILang.country[ "ly" ] = "Lībija";

theUILang.country[ "ma" ] = "Maroka";
theUILang.country[ "mc" ] = "Monaco";
theUILang.country[ "md" ] = "Moldova";
theUILang.country[ "me" ] = "Melnkalne";
theUILang.country[ "mg" ] = "Madagaskara";
theUILang.country[ "mh" ] = "Maršala salas";
theUILang.country[ "mk" ] = "Maķedonija";
theUILang.country[ "ml" ] = "Mali";
theUILang.country[ "mm" ] = "Mjanma";
theUILang.country[ "mn" ] = "Mongolija";
theUILang.country[ "mo" ] = "Makao";
theUILang.country[ "mp" ] = "Ziemeļu Marianas salas";
theUILang.country[ "mq" ] = "Martinika";
theUILang.country[ "mr" ] = "Mauritānija";
theUILang.country[ "ms" ] = "Montserrat";
theUILang.country[ "mt" ] = "Malta";
theUILang.country[ "mu" ] = "Maurīcija";
theUILang.country[ "mv" ] = "Maldivu salas";
theUILang.country[ "mw" ] = "Malāvija";
theUILang.country[ "mx" ] = "Meksika";
theUILang.country[ "my" ] = "Malaizija";
theUILang.country[ "mz" ] = "Mozambika";

theUILang.country[ "na" ] = "Namībija";
theUILang.country[ "nc" ] = "Jaunā Kaledonija";
theUILang.country[ "ne" ] = "Nigēra";
theUILang.country[ "nf" ] = "Norfolkas Sala";
theUILang.country[ "ng" ] = "Nigērija";
theUILang.country[ "ni" ] = "Nikaragva";
theUILang.country[ "nl" ] = "Nīderlande";
theUILang.country[ "no" ] = "Norvēģija";
theUILang.country[ "np" ] = "Nepāla";
theUILang.country[ "nr" ] = "Nauru";
theUILang.country[ "nu" ] = "Niue";
theUILang.country[ "nz" ] = "Jaunzēlande";

theUILang.country[ "om" ] = "Omāna";

theUILang.country[ "pa" ] = "Panama";
theUILang.country[ "pe" ] = "Peru";
theUILang.country[ "pf" ] = "Franču Polinēzija";
theUILang.country[ "pg" ] = "Papua Jaungvineja";
theUILang.country[ "ph" ] = "Filipīnas";
theUILang.country[ "pk" ] = "Pakistāna";
theUILang.country[ "pl" ] = "Polija";
theUILang.country[ "pm" ] = "Senpjēra un Mikelona";
theUILang.country[ "pn" ] = "Pitkērna";
theUILang.country[ "pr" ] = "Puerto Rico";
theUILang.country[ "ps" ] = "Palestīna";
theUILang.country[ "pt" ] = "Portugāle";
theUILang.country[ "pw" ] = "Palau";
theUILang.country[ "py" ] = "Paragvajas";

theUILang.country[ "qa" ] = "Katara";

theUILang.country[ "re" ] = "Reinjona";
theUILang.country[ "ro" ] = "Rumānija";
theUILang.country[ "rs" ] = "Serbija";
theUILang.country[ "ru" ] = "Krievija";
theUILang.country[ "rw" ] = "Ruanda";

theUILang.country[ "sa" ] = "Saūda Arābija";
theUILang.country[ "sb" ] = "Zālamana salas";
theUILang.country[ "sc" ] = "Seišelu salas";
theUILang.country[ "sd" ] = "Sudāna";
theUILang.country[ "se" ] = "Zviedrija";
theUILang.country[ "sg" ] = "Singapūra";
theUILang.country[ "sh" ] = "Saint Helena";
theUILang.country[ "si" ] = "Slovēnija";
theUILang.country[ "sj" ] = "Svalbāras arhipelāgs un Jana Majena sala";
theUILang.country[ "sk" ] = "Slovākija";
theUILang.country[ "sl" ] = "Sjerraleone";
theUILang.country[ "sm" ] = "Sanmarīno";
theUILang.country[ "sn" ] = "Senegāla";
theUILang.country[ "so" ] = "Somālija";
theUILang.country[ "sr" ] = "Surinama";
theUILang.country[ "ss" ] = "Dienvidsudānā";
theUILang.country[ "st" ] = "Santome un Prinsipi";
theUILang.country[ "sv" ] = "El Salvador";
theUILang.country[ "sy" ] = "Sīrija";
theUILang.country[ "sz" ] = "Svazilenda";

theUILang.country[ "tc" ] = "Terkasas un Kaikosas salas";
theUILang.country[ "td" ] = "Čada";
theUILang.country[ "tf" ] = "Franču dienvidu teritorijas";
theUILang.country[ "tg" ] = "Togo";
theUILang.country[ "th" ] = "Taizeme";
theUILang.country[ "tj" ] = "Tadžikistāna";
theUILang.country[ "tk" ] = "Tokelau";
theUILang.country[ "tl" ] = "Timora-Leste";
theUILang.country[ "tm" ] = "Turkmenistāna";
theUILang.country[ "tn" ] = "Tunisija";
theUILang.country[ "to" ] = "Tonga";
theUILang.country[ "tr" ] = "Turcija", 
theUILang.country[ "tp" ] = "Portugāļu Timora";
theUILang.country[ "tt" ] = "Trinidāda un Tobāgo";
theUILang.country[ "tv" ] = "Tuvalu";
theUILang.country[ "tw" ] = "Taivāna";
theUILang.country[ "tz" ] = "Tanzānija";

theUILang.country[ "ua" ] = "Ukraina";
theUILang.country[ "ug" ] = "Uganda";
theUILang.country[ "uk" ] = "Apvienotā Karaliste";
theUILang.country[ "um" ] = "ASV Mazās Aizjūras salas";
theUILang.country[ "un" ] = "Nezināms";
theUILang.country[ "us" ] = "Savienotās Valstis";
theUILang.country[ "uy" ] = "Urugvaja";
theUILang.country[ "uz" ] = "Uzbekistan";

theUILang.country[ "va" ] = "Vatican";
theUILang.country[ "vc" ] = "Sentvinsenta un Grenadīnas";
theUILang.country[ "ve" ] = "Venecuēla";
theUILang.country[ "vg" ] = "Britu Virdžīnu salas";
theUILang.country[ "vi" ] = "ASV Virdžīnu salas";
theUILang.country[ "vn" ] = "Viet Nam";
theUILang.country[ "vu" ] = "Vanuatu";

theUILang.country[ "wf" ] = "Volisa un Futunas salas";
theUILang.country[ "ws" ] = "Samoa";

theUILang.country[ "ye" ] = "Jemena";
theUILang.country[ "yt" ] = "Majota";

theUILang.country[ "za" ] = "Dienvidāfrika";
theUILang.country[ "zm" ] = "Zambija";
theUILang.country[ "zw" ] = "Zimbabve";

thePlugins.get("geoip").langLoaded();