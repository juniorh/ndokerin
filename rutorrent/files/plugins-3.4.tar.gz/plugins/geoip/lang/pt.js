﻿
// Contributed by art.spb, December 2009.

theUILang.countryName = "País";

theUILang.country = new Array();

theUILang.country[ "ad" ] = "Andorra";
theUILang.country[ "ae" ] = "Emirados Árabes Unidos";
theUILang.country[ "af" ] = "Afeganistão";
theUILang.country[ "ag" ] = "Antígua e Barbuda";
theUILang.country[ "ai" ] = "Anguilla";
theUILang.country[ "al" ] = "Albânia";
theUILang.country[ "am" ] = "Armenia";
theUILang.country[ "an" ] = "Antilhas Holandesas";
theUILang.country[ "ao" ] = "Angola";
theUILang.country[ "aq" ] = "Antártida";
theUILang.country[ "ar" ] = "Argentina";
theUILang.country[ "as" ] = "American Samoa";
theUILang.country[ "at" ] = "Áustria";
theUILang.country[ "au" ] = "Australia";
theUILang.country[ "aw" ] = "Aruba";
theUILang.country[ "ax" ] = "Åland Islands";
theUILang.country[ "az" ] = "Azerbaijão";

theUILang.country[ "ba" ] = "Bósnia e Herzegovina";
theUILang.country[ "bb" ] = "Barbados";
theUILang.country[ "bd" ] = "Bangladesh";
theUILang.country[ "be" ] = "Bélgica";
theUILang.country[ "bf" ] = "Burkina Faso";
theUILang.country[ "bg" ] = "Bulgária";
theUILang.country[ "bh" ] = "Bahrain";
theUILang.country[ "bi" ] = "Burundi";
theUILang.country[ "bj" ] = "Benin";
theUILang.country[ "bm" ] = "Bermuda";
theUILang.country[ "bn" ] = "Brunei";
theUILang.country[ "bo" ] = "Bolívia";
theUILang.country[ "br" ] = "Brasil";
theUILang.country[ "bs" ] = "Bahamas";
theUILang.country[ "bt" ] = "Butão";
theUILang.country[ "bv" ] = "Bouvet Island";
theUILang.country[ "bw" ] = "Botswana";
theUILang.country[ "by" ] = "Belarus";
theUILang.country[ "bz" ] = "Belize";

theUILang.country[ "ca" ] = "Canadá";
theUILang.country[ "cc" ] = "Ilhas Cocos";
theUILang.country[ "cd" ] = "Congo-Kinshasa";
theUILang.country[ "cf" ] = "Central Africano República";
theUILang.country[ "cg" ] = "Congo-Brazzaville";
theUILang.country[ "ch" ] = "Suíça";
theUILang.country[ "ci" ] = "Costa do Marfim";
theUILang.country[ "ck" ] = "Ilhas Cook";
theUILang.country[ "cl" ] = "Chile";
theUILang.country[ "cm" ] = "Camarões";
theUILang.country[ "cn" ] = "China";
theUILang.country[ "co" ] = "Colômbia";
theUILang.country[ "cr" ] = "Costa Rica";
theUILang.country[ "cu" ] = "Cuba";
theUILang.country[ "cv" ] = "Cabo Verde";
theUILang.country[ "cx" ] = "Christmas Island";
theUILang.country[ "cy" ] = "Chipre";
theUILang.country[ "cz" ] = "República Checa";

theUILang.country[ "de" ] = "Alemanha";
theUILang.country[ "dj" ] = "Djibouti";
theUILang.country[ "dk" ] = "Dinamarca";
theUILang.country[ "dm" ] = "Dominica";
theUILang.country[ "do" ] = "República Dominicana";
theUILang.country[ "dz" ] = "Argélia";

theUILang.country[ "ec" ] = "Equador";
theUILang.country[ "ee" ] = "Estónia";
theUILang.country[ "eg" ] = "Egito";
theUILang.country[ "eh" ] = "Sahara Ocidental";
theUILang.country[ "er" ] = "Eritreia";
theUILang.country[ "es" ] = "Espanha";
theUILang.country[ "et" ] = "Etiópia";
theUILang.country[ "eu" ] = "União Europeia";

theUILang.country[ "fi" ] = "Finlândia";
theUILang.country[ "fj" ] = "Fiji";
theUILang.country[ "fk" ] = "Falkland Islands";
theUILang.country[ "fm" ] = "Micronésia";
theUILang.country[ "fo" ] = "Faroe Islands";
theUILang.country[ "fr" ] = "France";

theUILang.country[ "ga" ] = "Gabão";
theUILang.country[ "gb" ] = "Reino Unido";
theUILang.country[ "gd" ] = "Granada";
theUILang.country[ "ge" ] = "Georgia";
theUILang.country[ "gf" ] = "Guiana Francesa";
theUILang.country[ "gg" ] = "Guernsey";
theUILang.country[ "gh" ] = "Gana";
theUILang.country[ "gi" ] = "Gibraltar";
theUILang.country[ "gl" ] = "Gronelândia";
theUILang.country[ "gm" ] = "Gâmbia";
theUILang.country[ "gn" ] = "Guiné";
theUILang.country[ "gp" ] = "Guadalupe";
theUILang.country[ "gq" ] = "Guiné Equatorial";
theUILang.country[ "gr" ] = "Grécia";
theUILang.country[ "gs" ] = "Geórgia do Sul e Ilhas Sandwich do Sul";
theUILang.country[ "gt" ] = "Guatemala";
theUILang.country[ "gu" ] = "Guam";
theUILang.country[ "gw" ] = "Guiné-Bissau";
theUILang.country[ "gy" ] = "Guiana";

theUILang.country[ "hk" ] = "Hong Kong";
theUILang.country[ "hm" ] = "Ilha Heard e McDonald Ilhas";
theUILang.country[ "hn" ] = "Honduras";
theUILang.country[ "hr" ] = "Croácia";
theUILang.country[ "ht" ] = "Haiti";
theUILang.country[ "hu" ] = "Hungria";

theUILang.country[ "id" ] = "Indonésia";
theUILang.country[ "ie" ] = "Irlanda";
theUILang.country[ "il" ] = "Israel";
theUILang.country[ "im" ] = "Isle of Man";
theUILang.country[ "in" ] = "Índia";
theUILang.country[ "io" ] = "Território Britânico do Oceano Índico";
theUILang.country[ "iq" ] = "Iraque";
theUILang.country[ "ir" ] = "O Irã";
theUILang.country[ "is" ] = "Islândia";
theUILang.country[ "it" ] = "Itália";

theUILang.country[ "je" ] = "Jersey";
theUILang.country[ "jm" ] = "Jamaica";
theUILang.country[ "jo" ] = "Jordan";
theUILang.country[ "jp" ] = "Japão";

theUILang.country[ "ke" ] = "Quênia";
theUILang.country[ "kg" ] = "Quirguistão";
theUILang.country[ "kh" ] = "Cambodia";
theUILang.country[ "ki" ] = "Quiribati";
theUILang.country[ "km" ] = "Comores";
theUILang.country[ "kn" ] = "Saint Kitts e Nevis";
theUILang.country[ "kp" ] = "A Coreia do Norte";
theUILang.country[ "kr" ] = "A Coréia do Sul";
theUILang.country[ "kw" ] = "Kuwait";
theUILang.country[ "ky" ] = "Cayman Islands";
theUILang.country[ "kz" ] = "Cazaquistão";

theUILang.country[ "la" ] = "Laos";
theUILang.country[ "lb" ] = "Líbano";
theUILang.country[ "lc" ] = "Santa Lúcia";
theUILang.country[ "li" ] = "Liechtenstein";
theUILang.country[ "lk" ] = "Sri Lanka";
theUILang.country[ "lr" ] = "Libéria";
theUILang.country[ "ls" ] = "Lesotho";
theUILang.country[ "lt" ] = "Lituânia";
theUILang.country[ "lu" ] = "Luxemburgo";
theUILang.country[ "lv" ] = "Letónia";
theUILang.country[ "ly" ] = "Líbia";

theUILang.country[ "ma" ] = "Marrocos";
theUILang.country[ "mc" ] = "Monaco";
theUILang.country[ "md" ] = "Moldávia";
theUILang.country[ "me" ] = "Montenegro";
theUILang.country[ "mg" ] = "Madagascar";
theUILang.country[ "mh" ] = "Ilhas Marshall";
theUILang.country[ "mk" ] = "Macedónia";
theUILang.country[ "ml" ] = "Mali";
theUILang.country[ "mm" ] = "Mianmar";
theUILang.country[ "mn" ] = "Mongólia";
theUILang.country[ "mo" ] = "Macau";
theUILang.country[ "mp" ] = "Ilhas Marianas do Norte";
theUILang.country[ "mq" ] = "Martinica";
theUILang.country[ "mr" ] = "Mauritânia";
theUILang.country[ "ms" ] = "Montserrat";
theUILang.country[ "mt" ] = "Malta";
theUILang.country[ "mu" ] = "Maurício";
theUILang.country[ "mv" ] = "Maldivas";
theUILang.country[ "mw" ] = "Malawi";
theUILang.country[ "mx" ] = "México";
theUILang.country[ "my" ] = "Malásia";
theUILang.country[ "mz" ] = "Moçambique";

theUILang.country[ "na" ] = "Namibia";
theUILang.country[ "nc" ] = "Nova Caledónia";
theUILang.country[ "ne" ] = "Niger";
theUILang.country[ "nf" ] = "Ilha Norfolk";
theUILang.country[ "ng" ] = "Nigéria";
theUILang.country[ "ni" ] = "Nicarágua";
theUILang.country[ "nl" ] = "Países Baixos";
theUILang.country[ "no" ] = "Noruega";
theUILang.country[ "np" ] = "Nepal";
theUILang.country[ "nr" ] = "Nauru";
theUILang.country[ "nu" ] = "Niue";
theUILang.country[ "nz" ] = "Nova Zelândia";

theUILang.country[ "om" ] = "Omã";

theUILang.country[ "pa" ] = "Panamá";
theUILang.country[ "pe" ] = "Peru";
theUILang.country[ "pf" ] = "Polinésia Francesa";
theUILang.country[ "pg" ] = "Papua Nova Guiné";
theUILang.country[ "ph" ] = "Filipinas";
theUILang.country[ "pk" ] = "Paquistão";
theUILang.country[ "pl" ] = "Polônia";
theUILang.country[ "pm" ] = "Saint Pierre e Miquelon";
theUILang.country[ "pn" ] = "Pitcairn";
theUILang.country[ "pr" ] = "Puerto Rico";
theUILang.country[ "ps" ] = "Palestina";
theUILang.country[ "pt" ] = "Portugal";
theUILang.country[ "pw" ] = "Palau";
theUILang.country[ "py" ] = "Paraguai";

theUILang.country[ "qa" ] = "Qatar";

theUILang.country[ "re" ] = "Reunião";
theUILang.country[ "ro" ] = "Roménia";
theUILang.country[ "rs" ] = "Sérvia";
theUILang.country[ "ru" ] = "Rússia";
theUILang.country[ "rw" ] = "Ruanda";

theUILang.country[ "sa" ] = "Arábia Saudita";
theUILang.country[ "sb" ] = "Ilhas Salomão";
theUILang.country[ "sc" ] = "Seychelles";
theUILang.country[ "sd" ] = "Sudão";
theUILang.country[ "se" ] = "Suécia";
theUILang.country[ "sg" ] = "Singapura";
theUILang.country[ "sh" ] = "Santa Helena";
theUILang.country[ "si" ] = "Eslovénia";
theUILang.country[ "sj" ] = "Svalbard e Jan Mayen";
theUILang.country[ "sk" ] = "Eslováquia";
theUILang.country[ "sl" ] = "Sierra Leone";
theUILang.country[ "sm" ] = "San Marino";
theUILang.country[ "sn" ] = "Senegal";
theUILang.country[ "so" ] = "Somália";
theUILang.country[ "sr" ] = "Suriname";
theUILang.country[ "ss" ] = "sul do Sudão";
theUILang.country[ "st" ] = "São Tomé e Príncipe";
theUILang.country[ "sv" ] = "El Salvador";
theUILang.country[ "sy" ] = "Síria";
theUILang.country[ "sz" ] = "Suazilândia";

theUILang.country[ "tc" ] = "Turks and Caicos Islands";
theUILang.country[ "td" ] = "Chad";
theUILang.country[ "tf" ] = "Territórios Franceses do Sul";
theUILang.country[ "tg" ] = "Togo";
theUILang.country[ "th" ] = "Tailândia";
theUILang.country[ "tj" ] = "Tajiquistão";
theUILang.country[ "tk" ] = "Tokelau";
theUILang.country[ "tl" ] = "Timor-Leste";
theUILang.country[ "tm" ] = "Turcomenistão";
theUILang.country[ "tn" ] = "Tunísia";
theUILang.country[ "to" ] = "Tonga";
theUILang.country[ "tr" ] = "Turquia";
theUILang.country[ "tp" ] = "Timor Português";
theUILang.country[ "tt" ] = "Trinidad e Tobago";
theUILang.country[ "tv" ] = "Tuvalu";
theUILang.country[ "tw" ] = "Taiwan";
theUILang.country[ "tz" ] = "Tanzânia";

theUILang.country[ "ua" ] = "Ucrânia";
theUILang.country[ "ug" ] = "Uganda";
theUILang.country[ "uk" ] = "Reino Unido";
theUILang.country[ "um" ] = "United States Minor Outlying Islands";
theUILang.country[ "un" ] = "Desconhecido";
theUILang.country[ "us" ] = "Estados Unidos";
theUILang.country[ "uy" ] = "Uruguai";
theUILang.country[ "uz" ] = "Uzbequistão";

theUILang.country[ "va" ] = "Vaticano";
theUILang.country[ "vc" ] = "São Vicente e Granadinas";
theUILang.country[ "ve" ] = "Venezuela";
theUILang.country[ "vg" ] = "Ilhas Virgens Britânicas";
theUILang.country[ "vi" ] = "Ilhas Virgens dos EUA";
theUILang.country[ "vn" ] = "Viet Nam";
theUILang.country[ "vu" ] = "Vanuatu";

theUILang.country[ "wf" ] = "Wallis e Futuna";
theUILang.country[ "ws" ] = "Samoa";

theUILang.country[ "ye" ] = "Iêmen";
theUILang.country[ "yt" ] = "Mayotte";

theUILang.country[ "za" ] = "África do Sul";
theUILang.country[ "zm" ] = "Zâmbia";
theUILang.country[ "zw" ] = "Zimbabwe";

thePlugins.get("geoip").langLoaded();