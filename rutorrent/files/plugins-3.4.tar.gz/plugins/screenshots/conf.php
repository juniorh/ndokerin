<?php

$pathToExternals['ffmpeg'] = '';		// Something like /usr/bin/ffmpeg. If empty, will be found in PATH.

?>