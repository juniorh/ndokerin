﻿

 theUILang.ratios		= "Групи коефіцієнтів";
 theUILang.ratio		= "Група коефіцієнтів";
 theUILang.mnuRatio		= "Установити коефіцієнт";
 theUILang.mnuRatioUnlimited	= "Немає";
 theUILang.ratioName		= "Назва";
 theUILang.minRatio		= "Мін.";
 theUILang.maxRatio		= "Макс.";
 theUILang.ratioUpload		= "Вивант.";
 theUILang.ratioAction		= "Дія";
 theUILang.ratioStop		= "Зупинити";
 theUILang.ratioStopAndRemove	= "Зупинити й очистити";
 theUILang.ratioErase		= "Видалити";
 theUILang.ratioEraseData	= "Видалити дані";
 theUILang.maxTime		= "Час";
 theUILang.ratioDefault 	= "Стандартна група коефіцієнтів";

thePlugins.get("ratio").langLoaded();
