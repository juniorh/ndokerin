﻿

 theUILang.ratios		= "Grupy ratio";
 theUILang.ratio		= "GrupaRatio";
 theUILang.mnuRatio		= "Ustaw grupę ratio";
 theUILang.mnuRatioUnlimited	= "Bez ratio";
 theUILang.ratioName		= "Nazwa";
 theUILang.minRatio		= "Minimum";
 theUILang.maxRatio		= "Maksimum";
 theUILang.ratioUpload		= "Wysyłanie";
 theUILang.ratioAction		= "Akcja";
 theUILang.ratioStop		= "Zatrzymaj";
 theUILang.ratioStopAndRemove	= "Zatrzymaj i wyczyść grupę";
 theUILang.ratioErase		= "Usuń";
 theUILang.ratioEraseData	= "Usuń dane";
 theUILang.maxTime		= "Czas";
 theUILang.ratioDefault 	= "Domyślna grupa ratio";

thePlugins.get("ratio").langLoaded();
