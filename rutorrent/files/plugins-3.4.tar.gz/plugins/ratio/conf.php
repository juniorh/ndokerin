<?php
// configuration parameters

@define('MAX_RATIO', 8, true);
$checkTimesInterval = 15	// in minutes

?>