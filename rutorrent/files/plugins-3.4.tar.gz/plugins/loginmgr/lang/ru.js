﻿

 theUILang.accLogin		= "Логин";
 theUILang.accPassword		= "Пароль";
 theUILang.accAccounts		= "Аккаунты";

thePlugins.get("loginmgr").langLoaded();
