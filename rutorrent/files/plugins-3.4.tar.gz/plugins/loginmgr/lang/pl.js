﻿

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Hasło";
 theUILang.accAccounts		= "Konta";

thePlugins.get("loginmgr").langLoaded();
