﻿

 theUILang.accLogin		= "Tên đăng nhập";
 theUILang.accPassword		= "Mật khẩu";
 theUILang.accAccounts		= "Tài khoản";

thePlugins.get("loginmgr").langLoaded();