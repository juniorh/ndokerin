﻿

 theUILang.accLogin		= "Логін";
 theUILang.accPassword		= "Пароль";
 theUILang.accAccounts		= "Облікові записи";

thePlugins.get("loginmgr").langLoaded();
