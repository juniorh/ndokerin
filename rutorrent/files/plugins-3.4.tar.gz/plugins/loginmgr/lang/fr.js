﻿/*
 * PLUGIN LoginMGR
 *
 * File Name: fr.js
 * 	French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.accLogin		= "Nom d'utilisateur";
 theUILang.accPassword		= "Mot de passe";
 theUILang.accAccounts		= "Comptes";

thePlugins.get("loginmgr").langLoaded();