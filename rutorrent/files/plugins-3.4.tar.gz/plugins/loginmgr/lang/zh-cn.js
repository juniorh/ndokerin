﻿

 theUILang.accLogin		= "登录";
 theUILang.accPassword		= "密码";
 theUILang.accAccounts		= "帐号";

thePlugins.get("loginmgr").langLoaded();