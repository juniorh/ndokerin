﻿/*
 * PLUGIN MEDIAINFO
 *
 * File Name: fr.js
 *      French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.mediainfo		= "Media info";