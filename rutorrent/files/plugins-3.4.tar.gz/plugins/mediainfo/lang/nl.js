﻿

 theUILang.mediainfo		= "Media Info";