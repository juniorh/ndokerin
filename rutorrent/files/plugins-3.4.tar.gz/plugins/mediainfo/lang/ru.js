﻿

 theUILang.mediainfo		= "Информация о файле";