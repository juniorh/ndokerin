﻿

 theUILang.mediainfo		= "Інформація про файл";
