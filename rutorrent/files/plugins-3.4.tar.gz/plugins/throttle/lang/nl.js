﻿

 theUILang.throttles		= "Beperkingen";
 theUILang.throttle		= "Snelheidsbeperking";
 theUILang.mnuThrottle		= "Zet beperking";
 theUILang.mnuUnlimited 	= "Geen Beperking";
 theUILang.channelName		= "Naam";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();